# Healthcare Analytics Platform — Starter

Examples of ETL, data validation, predictive modeling, and reporting pipelines. Do not store PHI in public repos.
