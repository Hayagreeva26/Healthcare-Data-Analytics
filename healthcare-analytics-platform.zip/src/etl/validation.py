import pandas as pd
import argparse

def validate_icd_codes(df, icd_list):
    invalid = df[~df['icd_code'].isin(icd_list)]
    return invalid

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--file")
    args = parser.parse_args()
    df = pd.read_csv(args.file)
    valid = ['I10','E11','J45']
    inv = validate_icd_codes(df, valid)
    print("Invalid codes count:", len(inv))
