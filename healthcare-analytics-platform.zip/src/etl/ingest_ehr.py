import boto3
import pandas as pd
import os
from dotenv import load_dotenv
load_dotenv()

def download_from_s3(key, bucket=None):
    s3 = boto3.client("s3", region_name=os.getenv("AWS_REGION"))
    bucket = bucket or os.getenv("S3_BUCKET")
    obj = s3.get_object(Bucket=bucket, Key=key)
    df = pd.read_csv(obj['Body'])
    return df
