import pandas as pd
from src.etl.validation import validate_icd_codes

def test_validate_icd_codes():
    df = pd.DataFrame({'icd_code':['I10','XXX']})
    inv = validate_icd_codes(df, ['I10'])
    assert len(inv) == 1
